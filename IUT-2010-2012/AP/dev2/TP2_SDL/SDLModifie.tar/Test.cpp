#include "BaseSDL.h"

ecran ec;

int main(int argc, char** argv)
{
	int vl1,vl2,vl3,vl4,vl5,vl6,vl7,vl8,vl9,vl10,vl11,vl12,vl13 ;
	                                int vl14,vl15,vl16,vl17,vl18,vl19,vl20,vl21,vl22,vl23,vl24,vl25,vl26 ;
  int vl27,vl28,vl29,vl30,vl31,vl32,vl33,vl34,vl35,vl36,vl37,vl38,vl39 ;
  ec = creerEcran();
 	vl29 = 1;vl21 = 10;	
	for (vl22 = 0; vl22 < 2; vl22++)
	{		
		vl23 = 0;
    vl24 = vl29;
		vl25 = vl21;
		for (vl26=vl29; vl26<=70; vl26++)
		{
	    	vl23 = (70-vl24) / 2;
				vl27 = 0;
	      while (vl27 <vl24)
				{
		        afficherPixel(ec, 550+vl23+vl27, vl25, 'V');
		        vl27=vl27+1 ;
				}
			vl24 += 1;
			vl25++;
		}
    vl21 += (70-vl29);
    vl29 += 10;
	}
  vl28 = 550+(70-15)/2;	vl20=0;
  while (vl20 < 60)
	  {
			vl27=0 ;
			while (vl27 < 15)		
	      {
	        afficherPixel(ec, vl28+vl27, vl21+vl20, 'J');
					vl27=vl27+1 ;
	      }
		 vl20=vl20+1 ;
	}
	vl19 = 1;
	vl11 = 150;	
	for (vl12 = 0; vl12 < 4; vl12++)
	{		
		vl13 = 0;
    vl14 = vl19;
		vl15 = vl11;
		for (vl16=vl19; vl16<=50; vl16++)
		{
	    	vl13 = (50-vl14) / 2;
				vl17 = 0;
	      while (vl17 <vl14)
				{
		        afficherPixel(ec, 450+vl13+vl17, vl15, 'V');
		        vl17=vl17+1 ;
				}
			vl14 += 1;
			vl15++;
		}
    vl11 += (50-vl19);    vl19 += 10;
	}
  vl18 = 450+(50-20)/2;
	vl10=0;
  while (vl10 < 50)
	  {
			vl17=0 ;
			while (vl17 < 20)		
	      {
	        afficherPixel(ec, vl18+vl17, vl11+vl10, 'J');
					vl17=vl17+1 ;
	      }
		 vl10=vl10+1 ;
	}
	vl39 = 1;
	vl31 = 350;	
	for (vl32 = 0; vl32 < 3; vl32++)
	{		
		vl33 = 0;
    vl34 = vl39;
		vl35 = vl31;
		for (vl36=vl39; vl36<=20; vl36++)
		{
	    	vl33 = (20-vl34) / 2;				vl37 = 0;
	      while (vl37 <vl34)
				{
		        afficherPixel(ec, 100+vl33+vl37, vl35, 'V');
		        vl37=vl37+1 ;
				}
			vl34 += 1;
			vl35++;
		}
    vl31 += (20-vl39);
    vl39 += 10;
	}
  vl38 = 100+(20-5)/2;
	vl30=0;
  while (vl30 < 15)
	  {
			vl37=0 ;
			while (vl37 < 5)		
	      {
	        afficherPixel(ec, vl38+vl37, vl31+vl30, 'J');
					vl37=vl37+1 ;
	      }
		 vl30=vl30+1 ;
	}
	vl12 = 0;	vl13 = 200;
	vl14 = 250;	for (vl15=200; vl15<=300; vl15++)
	{
		vl12 = (300-vl13) / 2;
		vl7 = 0;
    while (vl7 <vl13)
			{
        afficherPixel(ec, 150+vl12+vl7, vl14, 'B');
        vl7=vl7+1 ;
			}
		vl13 += 1;
		vl14++;
	}
	vl1=0;
  for (vl1 = 0; vl1 < 200; vl1++)
  {
		vl2 = 0;
    for (vl2 = 0; vl2<300; vl2++)
    {
      afficherPixel(ec, 150+vl2, 350+vl1, 'R');
    }
	}
  actualiser(ec);
  attendre();
  return EXIT_SUCCESS;
}




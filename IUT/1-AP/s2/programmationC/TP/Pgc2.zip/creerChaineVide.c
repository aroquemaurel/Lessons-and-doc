/* procedure creerChaineVide */

#include "chaine.h"

void creerChaineVide (ChaineDyn * ch)
{ 
    ch->nbCar = 0 ;
    ch->ptrCar = NULL ;
}

/* fonction longueurChaine */

#include "chaine.h"

int longueurChaine (ChaineDyn ch)
{ 
    return (ch.nbCar) ;
}

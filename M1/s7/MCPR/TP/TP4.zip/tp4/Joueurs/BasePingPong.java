// Base pour le jeu de ping pong sans synchronisation entre joueurs

// A modifier pour faire jouer un joueur Ping et un joueur Pong
// puis N joueurs Ping et M joueurs Pong
// avec N et M = parametres de l'application

public class BasePingPong {

	   public static void main(String[] args)  {
	          // Creation du comportement d'un joueur Ping (par exemple)
	          Joueur comportementJoueurPing = new Joueur(1, Joueur.PING);
	          // Creation du thread associe
	          Thread joueurPing = new Thread(comportementJoueurPing);
	          // Lancement du joueur
	          joueurPing.start();

	          System.out.println("Fin lancement application BasePingPong_VRunnable");

	          System.out.println("Fin application BasePingPong_VRunnable");
	        }
	}


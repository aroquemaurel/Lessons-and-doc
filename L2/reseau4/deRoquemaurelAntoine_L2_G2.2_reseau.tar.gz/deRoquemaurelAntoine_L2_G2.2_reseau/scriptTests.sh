# Ce script de tests permet de tester efficacement l'implémentation de la couche 2. 
# Celui-ci sera executé en fonction des différents paramètres spécifiés dans couche_liaison.h
# pour lancer les tests avec soleil.jpg, modification de la variable $IN 

pkill recepteur
pkill emetteur
make clean >> /dev/null 2> /dev/null && make all >> /dev/null 2> /dev/null
IN="in.txt"
OUT="out.txt"
errors=0

function test()
{
	sl=$1
	./recepteurSl$sl > recepteur.log &
	./emetteurSl$sl > emetteur.log 
	code=$?		
	if [ ! $code -eq 0 ]
	then
		echo -e "\033[31m[$i][sl$sl] Code d'erreur incorrect ($code)\033[0m"
		errors=`expr $errors + 1` 
	elif ! diff $IN $OUT 
	then
		echo -e "\033[31m[$i][sl$sl] Les fichiers $IN et $OUT sont différents\033[0m"
		errors=`expr $errors + 1` 
	fi
	sleep 5  
	
	if pkill recepteur
	then
		echo -e "\033[31m[$i][sl$sl] Erreur de terminaison du recepteur\033[0m"
		errors=`expr $errors + 1` 
	fi
	if pkill emetteur
	then
		echo -e "\033[31m[$i][sl$sl] Erreur de terminaison de l'émetteur\033[0m"
		errors=`expr $errors + 1` 
	fi

	if [ $errors -eq 0 ]
	then
		echo -e "\033[32m[$i][sl$sl] Passed\033[0m"
	else
		echo -e "\033[31m[$i][sl$sl] Failed ($errors erreur(s)\033[0m"
	fi
}
	echo -e "\033[33m=== Service Liaison 0 ===\033[0m"
#test 0 ## Test failed si erreurs
	echo -e "\033[33m=== Service Liaison 1 ===\033[0m"
#test 1 ## Test failed si erreurs
for sl in `seq 2 3`
do
	rm $OUT
	echo -e "\033[33m=== Service Liaison $sl ===\033[0m"
	for i in `seq 1 10` 
	do
		test $sl
		errors=0
	done
	echo ""
done

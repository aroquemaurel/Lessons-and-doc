#include "service_liaison.h"

void emettre_sur_liaison(char* adr_src, char* adr_dest, char* msg, int lg_msg) {
 	int i;
	trame_t trame;

	trame.deb_trame = 0;
 	for(i=0; i < 6 ; ++i) {
		trame.adr_src[i] = adr_src[i];
		trame.adr_dst[i] = adr_dest[i];
	}

	trame.lg_info = lg_msg;
	for(i = 0 ; i < lg_msg; ++i) {
		trame.info[i] = msg[i];
	}
	trame.fin_trame = i;
	trame.ctrl = CTRL_TRANSFERT_DONNEES; 

	vers_canal(&trame, sizeof(trame_t));
}

int recevoir_de_liaison(char* adr_src, char* adr_dest,char* msg) {
	trame_t trame;
	int i;
	if(attendre() == RECEPTION) {
		de_canal(&trame,sizeof(trame));
		for(i = 0 ; i < trame.lg_info; ++i) {
			msg[i] = trame.info[i];
		}
	}
	return trame.lg_info;
}


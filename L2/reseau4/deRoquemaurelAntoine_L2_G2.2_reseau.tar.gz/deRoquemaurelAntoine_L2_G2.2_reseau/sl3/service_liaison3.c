#include "service_liaison.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

char gAdrSrc[6];
char gAdrDst[6];

trame_t remplirTrame(char* msg, int lg_msg, int num_seq) {
	int i;
	trame_t trame;
	trame.deb_trame = 0;
	trame.lg_info = lg_msg;
	trame.fcs = 0;
	for(i = 0 ; i < lg_msg; ++i) {
		trame.info[i] = msg[i];
		trame.fcs ^= trame.info[i]; 
	}
	trame.fin_trame = i;
	trame.ctrl = 4;

	trame.num_seq = num_seq;
	return trame;
}

/*  Primitive de demande d'établissement d'une connexion */
/*  Equivalent dans le monde OSI : L_CONNECT.req et L_CONNECT.conf */
/*  Valeur de retour : réponse à la demande de connexion
 *  (1 acceptation, 0 refus) */
int etablir_connexion_liaison(char* adr_src, char* adr_dest) {
	trame_t trame;
	trame_t reception;
	trame_t ack;
	int i;
	static int nbEssai=0;
	static int premierAppel=1;

	if(premierAppel) {
		initialisation_simple(TAUX_PERTE_EMETTEUR, TAUX_ERREUR_EMETTEUR, 0); // TODO distribué
		premierAppel = 0;
	}

	trame.ctrl = CTRL_DEMANDE_CONNEXION;
	trame.deb_trame = trame.fin_trame = trame.num_seq = trame.lg_info = 0;
	ack = trame;
	ack.ctrl = CTRL_ACK_POSITIF;
	
	vers_canal(&trame, sizeof(trame_t)); 
	depart_compteur(1,TPS_TIMER);

	switch(attendre()) {
		case RECEPTION:
			de_canal(&reception,sizeof(trame_t)); 
			nbEssai=0;
			if(reception.ctrl == CTRL_ACCEPTATION_CONNEXION) {
				for(i=0; i < 6 ; ++i) {
					gAdrDst[i] = adr_dest[i];
					gAdrSrc[i] = adr_src[i];
				}
			}
			vers_canal(&ack, sizeof(trame_t));
			arreter_compteur(1);
			break;
		case 1:
			 // Le compteur à claqué
			if(nbEssai >= NB_ESSAI) {
				fprintf(stderr, "Impossible d'envoyer cette trame. Erreur de connexion");
				exit(1);
			}
			++nbEssai;
			return etablir_connexion_liaison(adr_src, adr_dest);
			break;
	}

	return (reception.ctrl == CTRL_ACCEPTATION_CONNEXION);
}

/*  Primitive pour notifier d’une demande de connexion */
/*  Equivalent dans le monde OSI : L_CONNECT.ind */
void recevoir_demande_connexion_liaison(char* adr_src, char* adr_dest) {
	trame_t trame;
	int i;

    initialisation_simple(TAUX_PERTE_RECEPTEUR, TAUX_ERREUR_RECEPTEUR, 1); // TODO distribué

	if(attendre() == RECEPTION) {
		de_canal(&trame,sizeof(trame_t)); 
		if(trame.ctrl == 0) {
			repondre_demande_connexion_liaison(1); // on est toujours ok
			for(i = 0 ; i < 6 ; ++i) {
				gAdrSrc[i] = adr_src[i];
				gAdrDst[i] = adr_dest[i];
			}
		}
	}
}

/*  Primitive de réponse à la demande de connexion */
/*  Equivalent dans le monde OSI : L_CONNECT.resp */
void repondre_demande_connexion_liaison(int reponse) {
	trame_t trame;
	trame_t ack;

	trame.ctrl = (reponse == 1) ? 1 : 2;	
	trame.deb_trame = trame.fin_trame = trame.lg_info = 0;
	vers_canal(&trame,sizeof(trame_t));
	depart_compteur(1, TPS_TIMER);

	switch(attendre()) {
		case RECEPTION:
			de_canal(&ack,sizeof(trame_t)); 
			// Si on reçoit une trame autre que les premières données,
			// on relance, l'emetteur n'a pas eu la réponse
			if(ack.ctrl != 4 && ack.ctrl != 5) { //Ce n'est pas l'acquittement
				repondre_demande_connexion_liaison(reponse);
			}
			arreter_compteur(1);
			break;
		case 1:
			repondre_demande_connexion_liaison(reponse);
			break;
	}
}

/*  Primitive pour transférer une unité de données au sein d'une connexion */
/*  Equivalent dans le monde OSI : L_TX_DATA.req */
void emettre_sur_liaison_connectee(char* msg, int lg_msg) {
	static int numeroTrame = 0;
	static int nbEssai = 0;
	trame_t trame;
	trame_t ack;
	
	trame = remplirTrame(msg,lg_msg, numeroTrame);
	vers_canal(&trame, sizeof(trame_t));
	depart_compteur(1,TPS_TIMER);

	switch(attendre()) {
		case RECEPTION:
			 // on a reçus qque chose 
			de_canal(&ack,sizeof(trame_t));
			nbEssai = 0;
			if(ack.num_seq == numeroTrame && ack.ctrl == 5) { // c'est le bon acquittement
				++numeroTrame;
				arreter_compteur(1);
			} else {
				emettre_sur_liaison_connectee(msg,lg_msg);
			}
			break;
		case 1:
			 // Le compteur à claqué
			if(nbEssai >= NB_ESSAI) {
				fprintf(stderr, "Impossible d'envoyer cette trame. Erreur de connexion");
				exit(1);
			}
			++nbEssai;
			emettre_sur_liaison_connectee(msg,lg_msg);
			break;
	}
}

/*  Primitive pour récupérer une unité de données au sein d'une connexion */
/*  Equivalent dans le monde OSI : L_TX_DATA.ind */
/*  Valeur de retour : taille du message */
int recevoir_de_liaison_connectee(char* msg){
	int i;
	static int numeroTrame = 0;
	unsigned char fcs = 0;
	trame_t trame;
	trame_t ack;

	trame.lg_info = 0;
	ack = trame;
	ack.ctrl = 5;
	ack.fcs = 0;

	if(attendre() == RECEPTION) {
		de_canal(&trame,sizeof(trame)); 
		for(i = 0 ; i < trame.lg_info; ++i) {
			msg[i] = trame.info[i];
		}
		for(i = 0 ; i < trame.lg_info ; ++i) {
			fcs ^= trame.info[i]; 
		}
		ack.lg_info = 1;
		ack.num_seq = trame.num_seq;
		// Si la trame est valide et qu'on ne l'a pas déjà reçus
		if(fcs == trame.fcs && numeroTrame == trame.num_seq) {
			numeroTrame = trame.num_seq+1;
			ack.ctrl = 5;
		} else if(fcs != trame.fcs && numeroTrame == trame.num_seq) { 
			ack.ctrl = 6;
			trame.lg_info = 0;
		} else {// sinon on rejette la trame
			trame.lg_info = 0;
		}
		vers_canal(&ack, sizeof(trame_t));	

//		sleep(1);
//		Si c'est la dernière trame, on attend d'être sûr que l'acquittement soit
//		bien arrivé pour le renvoyer le cas échéant
		if(trame.info[0] == '\a') { 
			depart_compteur(1,TPS_TIMER+(TPS_TIMER/2));
			switch(attendre()) {
				case RECEPTION:
					arreter_compteur(1);
					recevoir_de_liaison_connectee(msg);
					break;
				case 2:
					return trame.lg_info;
					break;
			}
		}
	}

	return trame.lg_info;
}

/*  Primitive pour mettre fin à une connexion */
/*  Equivalent dans le monde OSI : L_DISCONNECT.req */
void terminer_connexion_liaison(void) {
	static int nbEssais = 0;
	trame_t trame;
	trame_t ack;

	trame.ctrl = 3;
	trame.deb_trame = 0;
	trame.fin_trame = 0;
	trame.num_seq = 0;
	trame.lg_info = 0;

	vers_canal(&trame, sizeof(trame_t)); 
	depart_compteur(1, TPS_TIMER);
	switch(attendre()) {
		case RECEPTION:
			de_canal(&ack,sizeof(trame_t)); 
			arreter_compteur(1);
			if(ack.ctrl != 5 || ack.num_seq != 5) {
				terminer_connexion_liaison();
			}
			break;
		case 1:
			if(++nbEssais < 5) {
				terminer_connexion_liaison();		
			}
			break;
	}

}

void envoyerAckTerminaisonConnexion(void) {
	trame_t ack;
	trame_t trame;

	ack.ctrl = 5; 
	ack.deb_trame = ack.fin_trame = ack.lg_info = 0;
	ack.num_seq = 5;
	vers_canal(&ack, sizeof(trame_t));
	depart_compteur(1,TPS_TIMER+(TPS_TIMER/2));

	if(attendre() == RECEPTION) {
		de_canal(&trame,sizeof(trame_t)); 
		if(trame.ctrl == 3) {
			envoyerAckTerminaisonConnexion();
		}
		arreter_compteur(1);
	} 
}

/*  Primitive de notification d'une fermeture de connexion */
/*  Equivalent dans le monde OSI : L_DISCONNECT.ind */
void recevoir_terminaison_connexion_liaison(void) {
	trame_t trame;
	char msg[256];
	if(attendre() == RECEPTION) {
		de_canal(&trame,sizeof(trame_t)); 

		if(trame.ctrl == 3) {
			envoyerAckTerminaisonConnexion();
		} else if(trame.ctrl == 4) {
			recevoir_de_liaison_connectee(msg);
			recevoir_terminaison_connexion_liaison();
		} else {
			recevoir_terminaison_connexion_liaison();
		}
	}
}


/*************************************
 * UPS - L2 Informatique - Réseaux   *
 *                                   *
 * recepteur.c : programme principal *
 ************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "physique.h" /* Initialisation "physique" */
#include "service_liaison.h" /* emettre_sur_liaison, etc. */
#include "goBackN/fenetre.h" /*  Les fonctions sur le type Fenetre */
int reception(char* donnees);
/*
 * Parametres du programme :
 *   aucun en version simple (mode local)
 *   port_local, machine_destination, port_destination en version distribuee
 */
int main(int argc, char* argv[])
{
    char donnees[TAILLE_MAX+1]; /* Taille max des donnees : A DEFINIR */
 
    int i, lg_donnees;
    int cpt=0;
    int continuer = 1;
	int trameAttendue = 0;
    FILE* fich;
            
    /* Pour la version distribuee */ 
    // initialisation(0.f, 0.f, (short) atoi(argv[1]), argv[2], (short) atoi(argv[3]));
    
    /* Pour la version simple */
    initialisation_simple(TAUX_PERTE_RECEPTEUR, TAUX_ERREUR_RECEPTEUR, 1);

    /* Ouverture du fichier en ecriture */
    fich = fopen("out.txt", "w");
    if (fich == NULL) {
        printf("Fichier out.txt impossible a creer\n");
        return 1;
    }
	
    /* Tant qu'on n'a pas fini de recevoir */
    while (continuer) {
        /* On reinitialise le tableau donnees */
        for (i = 0; i < TAILLE_MAX; i++)
            donnees[i] = '\0';

		lg_donnees = reception(donnees);
        /* On regarde si c'est le dernier message */
        if (donnees[0]=='\a') {
            /* Fermeture fichier et arret de la boucle */
            printf("[couche appli] Fin de reception.\n");
            continuer = 0;
            fclose(fich);
        } else {
            printf("[couche appli] Reception numero %d\n\n",cpt);
            
            /* Ecriture des donnees dans le fichier */
            /* size_t fwrite(const void *ptr, size_t size, size_t nbitems, FILE *stream); */
            fwrite(donnees, sizeof(char), lg_donnees, fich);           
            fflush(fich);
            cpt++;
        }
		++trameAttendue;
    }
    return 0;
}
int reception(char* donnees) {
	int i=0 ;
	trame_t trame;
	trame_t ack;
	unsigned char fcs;
	static int trameAttendue=0;
	static int envoieAck = -1;

	switch(attendre()) {
		case RECEPTION:
			de_canal(&trame,sizeof(trame_t));
			ack = trame;
			ack.lg_info = ack.fin_trame = ack.deb_trame = trame.fcs = 0;
			ack.ctrl = 5;
			for(i=0 ; i < TAILLE_MAX; ++i) {
				fcs = trame.fcs;
			}
			for(i=0 ; i < 6 ; ++i) {
				ack.adr_dst[i] = trame.adr_dst[i];
				ack.adr_src[i] = trame.adr_src[i];
			}
				
			// si trame valide
			if(trame.fcs == fcs) {	
				if(trameAttendue == trame.num_seq) {
					for(i=0 ; i < trame.lg_info ; ++i) {
						donnees[i] = trame.info[i];
					}
					envoieAck = -1;	
					if(trameAttendue == 6) {
						ack.num_seq = TAILLE_FENETRE;
						vers_canal(&ack,sizeof(trame_t));
						// ack 8
					} 
				} else if(envoieAck == -1 || trame.num_seq <= envoieAck) {
					ack.num_seq = trameAttendue; 
					trameAttendue = 0;
					vers_canal(&ack,sizeof(trame_t));
					envoieAck = ack.num_seq;
					return 0;
			//		// ack trameactuelle
				} else {
					return 0;
				}
				trameAttendue = (trameAttendue+1 > 6) ? 0 : trameAttendue+1;	
				break;
			} else {
				return 0;
			}
		}

	return i;
}

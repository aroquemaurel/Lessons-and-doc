/************************************
 * UPS - L2 Informatique - Réseaux  *
 *                                  *
 * emetteur.c : programme principal *
 ***********************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "service_liaison.h" /* emettre_sur_liaison, etc. */
#include "physique.h" /* Initialisation "physique" */
#include "goBackN/fenetre.h" /*  Les fonctions sur le type Fenetre */

Fenetre emission(Fenetre pFenetre, int fin) {
	int i ;
	static int nbEssai=0;
	Fenetre nouvelleFenetre = pFenetre;
	trame_t trame;
	//printf("%d", pFenetre->trame[0].num_seq);
	envoyerFenetre(nouvelleFenetre);
	switch(attendre()) {
		case RECEPTION:
			arreter_compteur(1);
			printf("test");
			de_canal(&trame,sizeof(trame_t));
			decalerFenetre(&nouvelleFenetre, trame.num_seq) ;
			if(fin) {
				nouvelleFenetre.fin = 1;
				if(trame.num_seq < nouvelleFenetre.nbTrames) {
					for(i=0 ; i < nouvelleFenetre.nbTrames ; ++i) {
						printf("%d ", i);
					}
					printf("%s", nouvelleFenetre.trame[6].info);

					nouvelleFenetre = emission(nouvelleFenetre, fin);
					//envoyerFenetre(nouvelleFenetre);
				} 
			}
			++nbEssai;
			break;
		case 1:
			if(nbEssai < 5 ) {
				nouvelleFenetre = emission(nouvelleFenetre, fin);
			}
			break;
	}

	return nouvelleFenetre;
}
/*
 * Parametres du programme :
 *   aucun en version simple (mode local)
 *   port_local, machine_destination, port_destination en version distribuee
 */
int main(int argc, char* argv[])
{
	char addest[6] = {'A','A','A','A','A','\0'};
	char adsource[6] = {'B','B','B','B','B','\0'};
    FILE*	fich;
    int	lg ;
	Fenetre fenetre = nouvelleFenetre(adsource, addest);
	 
    /* Pour la version distribuee */ 
    //initialisation(0.f, 0.f, (short) atoi(argv[1]), argv[2], (short) atoi(argv[3]));
    
    /* Pour la version simple */
    initialisation_simple(TAUX_PERTE_EMETTEUR, TAUX_ERREUR_EMETTEUR, 0);
    /* Ouverture du fichier en lecture */
    fich = fopen("in.txt", "r");
 //   fich = fopen("soleil.jpg", "r");
    if (fich == NULL) {
        printf("Fichier in.txt non present\n");
        return 1;
    }
    /* Tant qu'on n'a pas fini de lire le fichier */
    while (!feof(fich)) {
		remplireFenetre(&fenetre,fich);
		if(fenetre.nbTrames < 7) {
			ajouterTrameFenetre(&fenetre, "\a ");
		}
		fenetre = emission(fenetre, feof(fich));
	}
	

	printf("[couche appli] Fin de transmission.\n");
	fclose(fich);
	return 0;
}


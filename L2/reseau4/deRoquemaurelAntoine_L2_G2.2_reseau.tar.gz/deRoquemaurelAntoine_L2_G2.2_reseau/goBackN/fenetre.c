#include "goBackN/fenetre.h"
trame_t nouvelleTrame(char* adr_src, char* adr_dest) {
	trame_t trame;
	int i;

	for(i=0 ; i < 6 ; ++i) {
		trame.adr_dst[i] = adr_dest[i];
		trame.adr_src[i] = adr_src[i];
	}

	trame.deb_trame = trame.fin_trame = trame.num_seq = trame.lg_info = trame.fcs = 0;

	return trame;
}

Fenetre nouvelleFenetre(char* adr_src, char* adr_dest) {
	Fenetre fenetre;
	trame_t trame = nouvelleTrame(adr_src, adr_dest);
	int i;
	fenetre.fin = 0;
	trame.ctrl = 4;
	for(i = 0 ; i < TAILLE_FENETRE ; ++i) {
		trame.num_seq = i;
		fenetre.trame[i] = trame;
	}
	fenetre.premiereTrame = 0;
}

void remplireFenetre(Fenetre* pFenetre, FILE* pFichier) {
    char donnees[TAILLE_MAX];
	int i=pFenetre->premiereTrame, j;
	int lg = 1;

	while(i < TAILLE_FENETRE && lg > 0) {
		lg = fread(pFenetre->trame[i].info, sizeof(char), TAILLE_MAX, pFichier);
		if(lg == 0) {
			pFenetre->trame[i].info[0] = '\a'; 
			pFenetre->trame[i].lg_info = 1;
			pFenetre->trame[i].num_seq = i;
			break;
		}

		pFenetre->trame[i].info[lg] = '\0'; 
		pFenetre->trame[i].lg_info = lg;
		pFenetre->trame[i].fin_trame = lg;
		pFenetre->trame[i].num_seq = i;
		++i;
	}
	pFenetre->nbTrames = (i>TAILLE_FENETRE) ? 0 : i;
}

void decalerFenetre(Fenetre* pFenetre, const int pNumAck) {
	int i,j;
  	for(i = pNumAck ; i < TAILLE_FENETRE ; ++i) {
		pFenetre->trame[i-pNumAck] = pFenetre->trame[i];
		for(j = 0 ; j < 6 ; ++j) {
			pFenetre->trame[i-pNumAck].adr_dst[j] = pFenetre->trame[i].adr_dst[j];
			pFenetre->trame[i-pNumAck].adr_src[j] = pFenetre->trame[i].adr_src[j];
		}
		for(j = 0 ; j < TAILLE_MAX ; ++j) {
			pFenetre->trame[i-pNumAck].info[j] = pFenetre->trame[i].info[j];
		}
	}
	
 	pFenetre->premiereTrame = (pNumAck > 6) ? 0 : pFenetre->nbTrames-pNumAck;
	pFenetre->nbTrames = TAILLE_FENETRE - pNumAck; 
	for(i=0 ; i < pFenetre->nbTrames ; ++i) {
		pFenetre->trame[i].num_seq = i;
	}

}

void envoyerFenetre(Fenetre pFenetre) {
	int i,j;
	static int cpt = 0;
	depart_compteur(1, TPS_TIMER); // TODO TESTME
	for(i = 0 ; i < pFenetre.nbTrames; ++i) {
		for(j = 0 ; j < TAILLE_MAX; ++j) {
			pFenetre.trame[i].fcs ^= pFenetre.trame[i].info[j];
		}
		printf("\n[couche appli] Envoi numero %d\n",cpt);
		vers_canal(&(pFenetre.trame[i]),sizeof(trame_t));
//			printf("%s", pFenetre.trame[i].info);
		++cpt;
	}
}

void ajouterTrameFenetre(Fenetre* pFenetre, char* pMessage) {
	int i;
	for(i = 0 ; pMessage[i] != '\0'; ++i) {
//		pFenetre->trame[pFenetre->nbTrames].info[i] = pMessage[i];
	}
		pFenetre->trame[pFenetre->nbTrames-1].info[0] = '\a'; 
	pFenetre->trame[pFenetre->nbTrames-1].lg_info = 1;
//	pFenetre->trame[pFenetre->nbTrames-1].info[i] = '\0';
}

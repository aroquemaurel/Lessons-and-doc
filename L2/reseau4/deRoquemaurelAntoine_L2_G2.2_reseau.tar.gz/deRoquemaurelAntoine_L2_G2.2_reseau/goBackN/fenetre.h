#ifndef __FENETRE
#define __FENETRE

#include "couche_liaison.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#define TAILLE_FENETRE 7
typedef struct {
	trame_t trame[TAILLE_FENETRE + 1];	
	int premiereTrame;
	int nbTrames;
	int fin;
} Fenetre;

trame_t nouvelleTrame(char* adr_src, char* adr_dest);
Fenetre nouvelleFenetre(char* adr_src, char* adr_dest);
void remplireFenetre(Fenetre* pFenetre, FILE* pFichier);
void decalerFenetre(Fenetre* pFenetre, const int pNumAck);
void envoyerFenetre(Fenetre pFenetre);
void ajouterTrameFenetre(Fenetre* pFenetre, char* pMessage);



#endif



#ifndef __COUCHE_LIAISON
#define __COUCHE_LIAISON

#define TAILLE_MAX 82 
#define TPS_TIMER  100 
#define NB_ESSAI   25

#define TAUX_PERTE_RECEPTEUR  0.4
#define TAUX_PERTE_EMETTEUR   0.4
#define TAUX_ERREUR_RECEPTEUR 0.4
#define TAUX_ERREUR_EMETTEUR  0.4

#define CTRL_DEMANDE_CONNEXION 0
#define CTRL_ACCEPTATION_CONNEXION 1
#define CTRL_REFUS_CONNEXION 2
#define CTRL_DEMANDE_DECONNEXION 3
#define CTRL_TRANSFERT_DONNEES 4
#define CTRL_ACK_POSITIF 5
#define CTRL_ACK_NEGATIF 6
#define CTRL_AUTRE

typedef struct trame_s {
	unsigned char deb_trame;
	unsigned char adr_dst[6];
	unsigned char adr_src[6];
	unsigned char ctrl;
	unsigned char num_seq;
	unsigned char lg_info;
	unsigned char info[TAILLE_MAX];
	unsigned char fcs;
	unsigned char fin_trame;
} trame_t;

#endif 

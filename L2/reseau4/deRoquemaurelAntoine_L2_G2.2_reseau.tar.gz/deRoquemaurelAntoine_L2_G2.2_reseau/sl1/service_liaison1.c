#include "service_liaison.h"
#include <unistd.h>

trame_t remplirTrame(char* adr_src, char* adr_dest, char* msg, int lg_msg, int num_seq) {
	int i;
	trame_t trame;

	trame.deb_trame = 0;
 	for(i=0; i < 6 ; ++i) {
		trame.adr_src[i] = adr_src[i];
		trame.adr_dst[i] = adr_dest[i];
	}

	trame.lg_info = lg_msg;
	for(i = 0 ; i < lg_msg; ++i) {
		trame.info[i] = msg[i];
	}
	trame.fin_trame = i;

	trame.ctrl = CTRL_TRANSFERT_DONNEES;
	trame.num_seq = num_seq;

	return trame;
}
void emettre_sur_liaison(char* adr_src, char* adr_dest, char* msg, int lg_msg) {
	static int numeroTrame = 0;
	trame_t trame;
	trame_t ack;
	
	trame = remplirTrame(adr_src, adr_dest, msg,lg_msg, numeroTrame);
	vers_canal(&trame, sizeof(trame_t));

	if(attendre() == RECEPTION) {
		de_canal(&ack,sizeof(trame_t));
		// c'est le bon acquittement
		if(ack.num_seq == numeroTrame && ack.ctrl == CTRL_ACK_POSITIF) { 
			numeroTrame = (numeroTrame + 1) % 2;
		}
 	}
}
int recevoir_de_liaison(char* adr_src, char* adr_dest,char* msg) {
	int i;
	static int numeroTrame = 0;
	trame_t trame;
	trame_t ack;

	trame.lg_info = 0;
	ack = trame;

	if(attendre() == RECEPTION) {
		de_canal(&trame,sizeof(trame));  // on reçoit la trame
		for(i = 0 ; i < trame.lg_info; ++i) {
			msg[i] = trame.info[i];
		}
		ack.lg_info = 1;
		ack.num_seq = trame.num_seq;
		if(numeroTrame == trame.num_seq) { // Si c'est la trame attendue
			numeroTrame = (trame.num_seq+1) % 2;
			ack.ctrl = CTRL_ACK_POSITIF; 
			vers_canal(&ack, sizeof(trame_t));	// on acquitte la trame
		} 

		sleep(1);
	}

	return trame.lg_info;
}


#include <stdio.h>
#include <stdlib.h>

int main (int argc, char** argv) {
	char character;	

	printf("Entrez un caractere svp ");
	scanf("%c", &character);
	printf("%d", character);

	return 0;
}

#ifndef ELEMENT_H 
#define ELEMENT_H
#include "pileStatique.h"
typedef PileStatique Element;
#endif

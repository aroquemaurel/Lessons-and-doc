#ifndef __COULEUR
#define __COULEUR

typedef enum { ROUGE, NOIR } Couleur;

#endif


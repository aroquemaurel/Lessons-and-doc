#ifndef __ERREUR
#define __ERREUR

void erreur(char* message, int retour);

#endif



#ifndef __UTIL
#define __UTIL

char** str_split(char* a_str, const char a_delim);
char *trim (char *str);
char *remove_newline(char *s);
char** trimTab(char** s, int nb);

#endif


